import { GoogleGenAI, Type } from "@google/genai";
import { StudentData, ValidationResponse } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const buildPrompt = (studentData: StudentData): string => {
  return `
    Role:
    Act as a financial document verification specialist experienced in analyzing fee receipts, UPI slips, cheque images, and campus-issued receipts.

    Task:
    Extract and validate payment proof details from the given image against the student’s record, and ensure that if a campus receipt is provided, it looks original and contains required elements.

    Context:
    - The student's record to validate against is:
      - Name: ${studentData.name}
      - Amount: ${studentData.amount}
      - Campus Name: ${studentData.campusName}
      - Payment Date: ${studentData.paymentDate}
      - UTR/Reference: ${studentData.utr}
    - The provided image may be a UPI screenshot, Bank transfer slip, Cheque copy, or a Campus-issued receipt.
    - Campus-issued receipts MUST include:
      - Campus/Institution name at the top
      - Official logo (mandatory)
      - Student details (e.g., name, ID, program)
      - Payment details (amount, date, mode, reference number)
    - Screenshots may be blurry, incomplete, or manually edited.

    Reasoning Steps:
    1. Access and analyze the attached image.
    2. Identify the type of proof (UPI, cheque, bank slip, campus-issued receipt).
    3. Extract the following details if visible: Student Name, Amount, Campus, Payment Date, Transaction Details / UTR / Receipt No., Reference Number.
    4. If the proof is a campus-issued receipt, you MUST verify if a logo is present. If the logo is missing, the receipt is invalid, regardless of other details. A stamp is optional.
    5. Compare extracted values against the provided student record.
    6. If all required checks pass, set Validation_Status to "Receipt Validated".
    7. If there's a mismatch or a missing mandatory element (especially a logo on a campus receipt), set Validation_Status to "Mismatch Found" and provide specific reasons in Observations.
    8. If the screenshot is too blurry, incomplete, or unreadable to perform validation, set Validation_Status to "Not Readable – Human Review Required."

    Constraints:
    - Do not guess or fabricate values if they are not visible in the image. Leave them as empty strings.
    - If a logo is missing on a campus-issued receipt, you must mark it as a mismatch.
    - Keep the response strictly within the defined JSON format.

    Format:
    Return the output strictly in the specified JSON format.
  `;
};

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        Extracted_Information: {
            type: Type.OBJECT,
            properties: {
                Student_Name: { type: Type.STRING },
                Amount: { type: Type.STRING },
                Campus: { type: Type.STRING },
                Payment_Date: { type: Type.STRING },
                Transaction_Details: { type: Type.STRING },
                Reference_Number: { type: Type.STRING },
                Proof_Type: { type: Type.STRING, enum: ['UPI', 'Cheque', 'Bank Slip', 'Campus Receipt', 'Unknown'] },
                Logo_Present: { type: Type.BOOLEAN },
                Stamp_Present: { type: Type.BOOLEAN },
            },
        },
        Validation_Status: {
            type: Type.STRING,
            enum: ['Receipt Validated', 'Mismatch Found', 'Not Readable – Human Review Required'],
        },
        Observations: { type: Type.STRING },
    },
};


export const validateReceipt = async (
  imageBase64: string,
  mimeType: string,
  studentData: StudentData
): Promise<ValidationResponse> => {
  try {
    const prompt = buildPrompt(studentData);
    const imagePart = {
      inlineData: {
        data: imageBase64,
        mimeType,
      },
    };
    const textPart = { text: prompt };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
        config: {
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        },
    });

    const jsonString = response.text.trim();
    return JSON.parse(jsonString) as ValidationResponse;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid') || error.message.includes('API_KEY_INVALID')) {
            throw new Error('Invalid API Key. Please ensure your API key is configured correctly.');
        }
        if (error.message.toLowerCase().includes('fetch failed') || error.message.toLowerCase().includes('network error')) {
            throw new Error('Network Error. Could not connect to the validation service. Please check your internet connection.');
        }
        throw new Error(`Gemini API Error: ${error.message}`);
    }
    throw new Error('An unknown error occurred during receipt validation.');
  }
};