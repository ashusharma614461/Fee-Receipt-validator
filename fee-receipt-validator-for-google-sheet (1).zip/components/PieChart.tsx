import React from 'react';

interface ChartData {
  name: string;
  value: number;
  color: string;
}

interface PieChartProps {
  data: ChartData[];
}

const PieChart: React.FC<PieChartProps> = ({ data }) => {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  if (total === 0) return null;

  const size = 150;
  const radius = size / 2;
  const cx = radius;
  const cy = radius;

  let cumulativeAngle = -90; // Start at the top

  const polarToCartesian = (centerX: number, centerY: number, r: number, angleInDegrees: number) => {
    const angleInRadians = (angleInDegrees * Math.PI) / 180.0;
    return {
      x: centerX + r * Math.cos(angleInRadians),
      y: centerY + r * Math.sin(angleInRadians),
    };
  };

  const describeArc = (x: number, y: number, r: number, startAngle: number, endAngle: number): string => {
    const start = polarToCartesian(x, y, r, endAngle);
    const end = polarToCartesian(x, y, r, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';
    const d = ['M', x, y, 'L', start.x, start.y, 'A', r, r, 0, largeArcFlag, 0, end.x, end.y, 'Z'].join(' ');
    return d;
  };
  
  return (
    <div className="bg-white p-4 rounded-lg shadow border border-gray-200 flex flex-col md:flex-row items-center justify-center gap-6">
      <div className="relative">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          {data.map((slice) => {
            const angle = (slice.value / total) * 360;
            const startAngle = cumulativeAngle;
            const endAngle = cumulativeAngle + angle;
            
            // Prevent tiny gaps between slices due to floating point inaccuracies
            const pathData = describeArc(cx, cy, radius, startAngle, endAngle - 0.5); 
            cumulativeAngle += angle;
            
            return <path key={slice.name} d={pathData} fill={slice.color} />;
          })}
        </svg>
      </div>
      <div className="w-full md:w-auto">
        <h3 className="text-lg font-semibold text-gray-700 mb-2 text-center md:text-left">Results Summary</h3>
        <ul className="space-y-1">
          {data.map((item) => {
            const percentage = ((item.value / total) * 100).toFixed(1);
            return (
              <li key={item.name} className="flex items-center justify-between gap-4 text-sm">
                <div className="flex items-center">
                   <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: item.color }}></span>
                   <span className="text-gray-600">{item.name}</span>
                </div>
                <span className="font-medium text-gray-800">{item.value} ({percentage}%)</span>
              </li>
            );
          })}
          <li className="flex items-center justify-between gap-4 text-sm font-bold border-t pt-1 mt-1 border-gray-200">
             <span className="text-gray-800">Total</span>
             <span className="text-gray-800">{total}</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default PieChart;
