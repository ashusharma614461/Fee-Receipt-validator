import React from 'react';
import { ProcessingResult } from '../types';
import { CheckCircleIcon, XCircleIcon, ExclamationCircleIcon } from './IconComponents';

interface ResultsTableProps {
  results: ProcessingResult[];
}

const ResultsTable: React.FC<ResultsTableProps> = ({ results }) => {

  const getStatusPill = (status: string | undefined, error?: string) => {
    if (error) {
        return <div className="flex items-center gap-2 text-red-700 bg-red-100 font-bold py-1 px-3 rounded-full text-xs"><XCircleIcon className="w-4 h-4"/>Processing Error</div>;
    }
    switch (status) {
      case 'Receipt Validated':
        return <div className="flex items-center gap-2 text-green-700 bg-green-100 font-bold py-1 px-3 rounded-full text-xs"><CheckCircleIcon className="w-4 h-4"/>Validated</div>;
      case 'Mismatch Found':
        return <div className="flex items-center gap-2 text-red-700 bg-red-100 font-bold py-1 px-3 rounded-full text-xs"><XCircleIcon className="w-4 h-4"/>Mismatch</div>;
      case 'Not Readable – Human Review Required':
        return <div className="flex items-center gap-2 text-amber-700 bg-amber-100 font-bold py-1 px-3 rounded-full text-xs"><ExclamationCircleIcon className="w-4 h-4"/>Needs Review</div>;
      default:
        return <div className="text-gray-700 bg-gray-100 font-bold py-1 px-3 rounded-full text-xs">{status}</div>;
    }
  };

  return (
    <div className="overflow-x-auto bg-white rounded-lg shadow border border-gray-200">
      <table className="min-w-full text-sm divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Name</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Amount</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">UTR</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Payment Date</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Status</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Observations</th>
            <th className="px-4 py-2 text-left font-semibold text-gray-600 uppercase tracking-wider">Validated At</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200">
          {results.map((result, index) => (
            <tr key={index} className={result.error ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50'}>
              <td className="px-4 py-3 whitespace-nowrap text-gray-800 font-medium">{result.originalData.name || 'N/A'}</td>
              <td className="px-4 py-3 whitespace-nowrap text-gray-600">{result.originalData.amount || 'N/A'}</td>
              <td className="px-4 py-3 whitespace-nowrap text-gray-600">{result.originalData.utr || 'N/A'}</td>
              <td className="px-4 py-3 whitespace-nowrap text-gray-600">{result.originalData.paymentDate || 'N/A'}</td>
              <td className="px-4 py-3 whitespace-nowrap">
                {getStatusPill(result.validation?.Validation_Status, result.error)}
              </td>
              <td className="px-4 py-3 text-gray-600 max-w-xs truncate" title={result.validation?.Observations || result.error}>
                {result.validation?.Observations || result.error || 'N/A'}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-gray-500">{result.timestamp}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ResultsTable;