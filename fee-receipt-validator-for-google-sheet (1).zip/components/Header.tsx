
import React from 'react';

const Header: React.FC = () => {
  return (
    <div className="text-center p-6 bg-white border-b border-gray-200 rounded-t-xl">
      <h1 className="text-4xl font-bold text-gray-800">Fee Receipt Validator</h1>
      <p className="text-lg text-gray-500 mt-2">
        Upload a CSV file of student records to begin AI-powered batch validation.
      </p>
    </div>
  );
};

export default Header;
